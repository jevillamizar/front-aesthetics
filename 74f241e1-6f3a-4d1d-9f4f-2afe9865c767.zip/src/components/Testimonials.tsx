import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';
const testimonials = [
{
  initial: 'S',
  name: 'Sarah M.',
  treatment: 'Botox & Fillers',
  rating: 5,
  quote:
  "I was nervous about looking 'done', but the results are so natural. Everyone says I look rested, not different. The team here is truly artistic."
},
{
  initial: 'J',
  name: 'Jennifer L.',
  treatment: 'HydraFacial',
  rating: 5,
  quote:
  'The most relaxing hour of my month. My skin has never looked better. The clinic is spotless and the staff makes you feel like royalty.'
},
{
  initial: 'E',
  name: 'Emily R.',
  treatment: 'CoolSculpting',
  rating: 5,
  quote:
  'Professional, knowledgeable, and caring. They walked me through every step of the process and the results exceeded my expectations.'
}];

export function Testimonials() {
  return (
    <section className="py-24 bg-[#F5F5F3]">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          className="text-center mb-16">

          <h2 className="text-3xl md:text-4xl font-light text-[#2D2D2D] mb-4">
            Patient Stories
          </h2>
          <p className="text-[#6B6B6B]">
            Trusted by over 10,000 happy patients
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) =>
          <motion.div
            key={i}
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: i * 0.1
            }}
            whileHover={{
              y: -5
            }}
            className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 cursor-default">

              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 rounded-full bg-[#8B9E8B]/10 flex items-center justify-center text-[#8B9E8B] font-serif font-medium text-xl">
                  {t.initial}
                </div>
                <div>
                  <h4 className="font-medium text-[#2D2D2D]">{t.name}</h4>
                  <p className="text-xs text-[#8B9E8B] uppercase tracking-wide">
                    {t.treatment}
                  </p>
                </div>
              </div>

              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, i) =>
              <Star
                key={i}
                className="w-4 h-4 fill-[#8B9E8B] text-[#8B9E8B]" />

              )}
              </div>

              <div className="relative">
                <Quote className="absolute -top-2 -left-2 w-8 h-8 text-[#8B9E8B]/10 rotate-180" />
                <p className="text-[#6B6B6B] leading-relaxed relative z-10 pl-4">
                  "{t.quote}"
                </p>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}