import React from 'react';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { About } from './components/About';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Button } from './components/ui/Button';
import { Menu } from 'lucide-react';
export function App() {
  return (
    <div className="min-h-screen bg-[#F5F5F3] font-sans text-[#2D2D2D]">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-[#F5F5F3]">
        <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
          <div className="text-2xl font-serif italic text-[#2D2D2D]">
            Lumina <span className="text-[#8B9E8B]">Aesthetics</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a
              href="#"
              className="text-sm font-medium text-[#6B6B6B] hover:text-[#8B9E8B] transition-colors">

              Treatments
            </a>
            <a
              href="#"
              className="text-sm font-medium text-[#6B6B6B] hover:text-[#8B9E8B] transition-colors">

              About
            </a>
            <a
              href="#"
              className="text-sm font-medium text-[#6B6B6B] hover:text-[#8B9E8B] transition-colors">

              Reviews
            </a>
            <a
              href="#"
              className="text-sm font-medium text-[#6B6B6B] hover:text-[#8B9E8B] transition-colors">

              Contact
            </a>
            <Button size="sm">Book Now</Button>
          </div>

          <button className="md:hidden p-2 text-[#2D2D2D]">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      <main>
        <Hero />
        <Services />
        <About />
        <Testimonials />
        <Contact />
      </main>
    </div>);

}